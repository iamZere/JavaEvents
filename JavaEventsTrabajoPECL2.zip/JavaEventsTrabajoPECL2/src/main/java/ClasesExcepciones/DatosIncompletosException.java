
package ClasesExcepciones;

/**
 *Clase para la excepción de Datos Incompletos
 * 
 * @author zerep
 */
public class DatosIncompletosException extends Exception{

    /**
     *
     * @param mensaje
     */
    public DatosIncompletosException(String mensaje) {
        super(mensaje);
     }
}
