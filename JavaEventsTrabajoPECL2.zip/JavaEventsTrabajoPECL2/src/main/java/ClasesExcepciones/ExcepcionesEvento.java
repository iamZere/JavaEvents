/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClasesExcepciones;

/**
 * Clase utilizada para las excepciones a la hora de crear un evento.
 * 
 * @author zerep
 */
public class ExcepcionesEvento extends Exception {
    
    /**
     * Constante para el mensaje de error cuando el título del evento es inválido.
     */
    public static final String TITULO_INVALIDO = "El título del evento es inválido.";
    
    /**
     * Constante para el mensaje de error cuando la dirección del evento es inválida.
     */
    public static final String DIRECCION_ENTRADA = "La dirección del evento es inválida.";
    
    /**
     * Constante para el mensaje de error cuando los datos del evento son inválidos.
     */
    public static final String DATOS_EVENTO_INVALIDOS= "Los datos del evento son inválidos.";
    
    /**
     * Constante para el mensaje de error cuando el tipo de evento es inválido.
     */
    public static final String TIPO_EVENTO_INVALIDO = "El tipo de evento es inválido.";
    
    /**
     * Constante para el mensaje de error cuando el precio del evento es inválido.
     */
    public static final String PRECIO_INVALIDO = "El precio del evento es inválido.";
    
    /**
     * Constante para el mensaje de error cuando la fotografía del evento es inválida.
     */
    public static final String FOTO_INVALIDA = "La fotografía del evento es inválida.";
    
    /**
     * Constante para el mensaje de error cuando la calificación del evento es inválida.
     */
    public static final String CALIFICACION_INVALIDA = "La calificación del evento es inválida.";
    
    /**
     * Constante para el mensaje de error cuando las fechas introducidas no son válidas.
     */
    public static final String FECHA_INVALIDA = "Las fechas introducidas no son válidas.";
    
    /**
     * Constructor predeterminado que establece un mensaje genérico.
     */
    public ExcepcionesEvento() {
        super("Se ha producido una excepción en la aplicación.");
    }
    
    /**
     * Constructor que permite especificar un mensaje de error personalizado.
     * @param txt El mensaje de error personalizado.
     */
    public ExcepcionesEvento(String txt) {
        super(txt);
    }
    
}
