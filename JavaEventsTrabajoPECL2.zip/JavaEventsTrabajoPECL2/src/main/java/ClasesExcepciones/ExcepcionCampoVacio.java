/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClasesExcepciones;

/**
 * Clase para la excepción de Campos Vacíos
 * 
 * @author zerep
 */

public class ExcepcionCampoVacio extends Exception {
    
    /**
     * Constructor de la excepción que establece un mensaje por defecto.
     */
    public ExcepcionCampoVacio() {
        super("Por favor rellene todos los campos");
    }    
}
