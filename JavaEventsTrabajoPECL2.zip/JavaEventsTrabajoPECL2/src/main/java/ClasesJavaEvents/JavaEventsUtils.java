
package ClasesJavaEvents;

/**
 *Clase JavaEventsUtils que contiene los metodos más importantes de la aplicación
 * 
 * @author RAMON
 */
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 *
 * @author zerep
 */
public class JavaEventsUtils {
    
    /**
     *
     */
    public static ArrayList<Cliente> clientes = new ArrayList<>();
    private static Cliente objcliente;
    
    /**
     *
     */
    public static ArrayList<Evento> eventos = new ArrayList<>();
    private static Evento objevento;
    
    /**
     *
     */
    public static ArrayList<Reserva> reservas = new ArrayList<>();
    private static Reserva objreserva;

    /**
     *
     */
    public static ArrayList<Resena> resenas = new ArrayList<>();
    private static Reserva objresena;
    
    /** Establece el ArrayList de Clientes
     * @param c */
    public static void setClientes(ArrayList<Cliente> c) {
        clientes = c;
    }
    
    /** Establece el ArrayList de Eventos
     * @param e */
    public static void setEventos(ArrayList<Evento> e) {
        eventos = e;
    }
    
    /** Establece el ArrayList de Resenas
     * @param r */
    public static void setReservas(ArrayList<Reserva> r) {
        reservas = r;
    }
    
    
    /** Establece el ArrayList de Resenas
     * @param s */
    public static void setResenas(ArrayList<Resena> s) {
        resenas = s;
    }
    
    /** Devuelve el ArrayList de Clientes ordenados por Nombre
     * @return  */
    public static ArrayList<Cliente> getClientesPorNombre() {
        //Comparador para ordenar los Clientes por su Nombre
        Comparator NomcliComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Cliente c1 = (Cliente) o1;
                Cliente c2 = (Cliente) o2;
                return c1.getNombre().compareTo(c2.getNombre());
            }
        };
        //Ordenamos el array
        Collections.sort(clientes, NomcliComp);
        return clientes;
    }
    
    /** Devuelve el ArrayList de Clientes ordenados por Correo
     * @return  */
    public static ArrayList<Cliente> getClientesPorCorreo() {
        //Comparador para ordenar los Clientes por Correo
        Comparator CorreoComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Cliente c1 = (Cliente) o1;
                Cliente c2 = (Cliente) o2;
                return c1.getCorreo().compareTo(c2.getCorreo());
            }
        };
        //Ordenamos el array
        Collections.sort(clientes, CorreoComp);
        return clientes;
    }
    
    /** Devuelve el ArrayList de Clientes ordenados por Direccion
     * @return  */
    public static ArrayList<Cliente> getClientesPorDireccion() {
        //Comparador para ordenar los Clientes por su Direccion
        Comparator DireccionComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Cliente c1 = (Cliente) o1;
                Cliente c2 = (Cliente) o2;
                return c1.getDireccion().compareTo(c2.getDireccion());
            }
        };
        //Ordenamos el array
        Collections.sort(clientes, DireccionComp);
        return clientes;
    }
    
    /** Devuelve el ArrayList de Clientes ordenados por Clave
     * @return  */
    public static ArrayList<Cliente> getClientesPorClave() {
        //Comparador para ordenar los Productos por su Clave
        Comparator ClaveComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Cliente c1 = (Cliente) o1;
                Cliente c2 = (Cliente) o2;
                return c1.getClave().compareTo(c2.getClave());
            }
        };
        //Ordenamos el array
        Collections.sort(clientes, ClaveComp);
        return clientes;
    }
      
    /** Devuelve el ArrayList de Eventos ordenados por Titulo
     * @return  */
    public static ArrayList<Evento> getEventosPorTitulo() {
        //Comparador para ordenar los Eventos por su titulo
        Comparator TituloComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Evento e1 = (Evento) o1;
                Evento e2 = (Evento) o2;
                return e1.getTitulo().compareTo(e2.getTitulo());
            }
        };
        //Ordenamos el array
        Collections.sort(eventos, TituloComp);
        return eventos;
    }
    
    /** Devuelve el ArrayList de Eventos ordenados por Precio
     * @return  */
    public static ArrayList<Evento> getEventosPorPrecio() {
        //Comparador para ordenar los Eventos por su Precio
        Comparator PrecioComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Evento e1 = (Evento) o1;
                Evento e2 = (Evento) o2;
                return e1.getPrecioEntrada().compareTo(e2.getPrecioEntrada());
            }
        };
        //Ordenamos el array
        Collections.sort(eventos, PrecioComp);
        return eventos;
    }
    
    /** Devuelve el ArrayList de Eventos ordenados por Direccion
     * @return  */
    public static ArrayList<Evento> getEventosPorDireccion() {
        //Comparador para ordenar los Eventos por su direccion
        Comparator DireccionComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Evento e1 = (Evento) o1;
                Evento e2 = (Evento) o2;
                return e1.getDireccion().compareTo(e2.getDireccion());
            }
        };
        //Ordenamos el array
        Collections.sort(eventos, DireccionComp);
        return eventos;
    }
    
    /** Devuelve el ArrayList de Eventos ordenados por Fecha
     * @return  */
    public static ArrayList<Evento> getEventosPorFecha() {
        //Comparador para ordenar los Eventos por su Fecha
        Comparator FechaComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Evento e1 = (Evento) o1;
                Evento e2 = (Evento) o2;
                return e1.getFecha().compareTo(e2.getFecha());
            }
        };
        //Ordenamos el array
        Collections.sort(eventos, FechaComp);
        return eventos;
    }
    
    /** Devuelve el ArrayList de Eventos ordenados por Tipo
     * @return  */
    public static ArrayList<Evento> getEventosPorTipo() {
        //Comparador para ordenar los Eventos por su Tipo
        Comparator TipoComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Evento e1 = (Evento) o1;
                Evento e2 = (Evento) o2;
                return e1.getTipo().compareTo(e2.getTipo());
            }
        };
        //Ordenamos el array
        Collections.sort(eventos, TipoComp);
        return eventos;
    }
    
    /** Devuelve el ArrayList de Reservas ordenadas por Evento
     * @return  */
    public static ArrayList<Reserva> getReservasPorEvento() {
        //Comparador para ordenar los Reservas por su Evento
        Comparator ResEvComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Reserva r1 = (Reserva) o1;
                Reserva r2 = (Reserva) o2;
                return r1.getEvento().compareTo(r2.getEvento());
            }
        };
        //Ordenamos el array
        Collections.sort(reservas, ResEvComp);
        return reservas;
    }
    
    /** Devuelve el ArrayList de Reservas ordenadas por Cliente
     * @return  */
    public static ArrayList<Reserva> getReservasPorCliente() {
        //Comparador para ordenar los Reservas por su Cliente
        Comparator ResCliComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Reserva r1 = (Reserva) o1;
                Reserva r2 = (Reserva) o2;
                return r1.getCliente().compareTo(r2.getCliente());
            }
        };
        //Ordenamos el array
        Collections.sort(reservas, ResCliComp);
        return reservas;
    }
    
    /** Devuelve el ArrayList de Reservas ordenadas por Precio
     * @return  */
    public static ArrayList<Reserva> getReservasPorPrecio() {
        //Comparador para ordenar los Reservas por su Precio
        Comparator ResPreComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Reserva r1 = (Reserva) o1;
                Reserva r2 = (Reserva) o2;
                Double rr1 = r1.getImporte();
                Double rr2 = r2.getImporte();
                return rr1.compareTo(rr2);
            }
        };
        //Ordenamos el array
        Collections.sort(reservas, ResPreComp);
        return reservas;
    }
    
    /** Devuelve el ArrayList de Reservas ordenadas por Fecha
     * @return  */
    public static ArrayList<Reserva> getReservasPorFecha() {
        //Comparador para ordenar los Reservas por su Fecha
        Comparator ResFechComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Reserva r1 = (Reserva) o1;
                Reserva r2 = (Reserva) o2;;
                return r1.getFecha().compareTo(r2.getFecha());
            }
        };
        //Ordenamos el array
        Collections.sort(reservas, ResFechComp);
        return reservas;
    }
    
    
    /** Da de alta un Cliente
     * @param objcliente
     * @return  */
    public static boolean altaCliente(Cliente objcliente) {
        if (consultaClientePorCorreo(objcliente.getCorreo()) == null) {
            clientes.add(objcliente);
            return true;
        } else {
            return false;
        }
    }
    
    /** Da de baja un Cliente
     * @param objcliente
     * @return  */
    public static boolean bajaCliente(Cliente objcliente) {
        if (clientes.contains(objcliente)) {
            clientes.remove(objcliente);
            return true;
        } else {
            return false;
        }
    }
    
    /** Da de alta un Evento
     * @param objevento
     * @return  */
    public static boolean altaEvento(Evento objevento) {
        if (consultaEventoPorTitulo(objevento.getTitulo()) == null) {
            eventos.add(objevento);
            return true;
        } else {
            return false;
        }
    }
    
    /** Da de baja un Evento
     * @param objevento
     * @return  */
    public static boolean bajaEvento(Evento objevento) {
        if (eventos.contains(objevento)) {
            eventos.remove(objevento);
            return true;
        } else {
            return false;
        }
    }
    
    /** Da de alta una Reserva
     * @param objreserva
     * @return  */    
    public static boolean altaReserva(Reserva objreserva) {
        if (consultaReservaPorEvento(objreserva.getEvento()) == null &&
            consultaReservaPorCliente(objreserva.getCliente()) == null){
            reservas.add(objreserva);
            return true;
        } else {
            return false;
        }
    }
    
    /** Da de baja una Reserva
     * @param objreserva
     * @return  */
    public static boolean bajaReserva(Reserva objreserva) {
        if (reservas.contains(objreserva)) {
            reservas.remove(objreserva);
            return true;
        } else {
            return false;
        }
    }
    
    /** Devuelve un Cliente por la posición dentro del ArrayList
     * @param indice
     * @return  */
    public static Cliente consultaCliente(int indice) {
        objcliente = clientes.get(indice);
        return objcliente;
    }
    
    /** Devuelve un Evento por la posición dentro del ArrayList
     * @param indice
     * @return  */
    public static Evento consultaEvento(int indice) {
        objevento = eventos.get(indice);
        return objevento;
    }
    
    /** Devuelve una Reserva por la posición dentro del ArrayList
     * @param indice
     * @return  */
    public static Reserva consultaReserva(int indice) {
        objreserva = reservas.get(indice);
        return objreserva;
    }
    
    /** Consulta los datos de un Cliente por su correo
     * @param correo
     * @return  */
    public static Cliente consultaClientePorCorreo(String correo) {
        //Comparador para ordenar los Clientes por su correo
        Comparator CorreocliComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Cliente c1 = (Cliente) o1;
                Cliente c2 = (Cliente) o2;
                return c1.getCorreo().compareTo(c2.getCorreo());
            }
        };
        //Ordenamos el array
        Collections.sort(clientes, CorreocliComp);
        //creamos un Cliente con el código a buscar
        Cliente c = new Cliente();
        c.setCorreo(correo);
        int pos = Collections.binarySearch(clientes, c, CorreocliComp);
        if (pos >= 0) {
            objcliente = clientes.get(pos);
        } else {
            objcliente = null;
        }

        return objcliente;
    }
    /** Consulta los datos de un Evento por su titulo
     * @param titulo
     * @return  */
    public static Evento consultaEventoPorTitulo(String titulo) {
        //Comparador para ordenar los Clientes por su correo
        Comparator TituloevComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Evento e1 = (Evento) o1;
                Evento e2 = (Evento) o2;
                return e1.getTitulo().compareTo(e2.getTitulo());
            }
        };
        //Ordenamos el array
        Collections.sort(eventos, TituloevComp);
        //creamos un Evento con el código a buscar
        Evento e = new Evento();
        e.setTitulo(titulo);
        int pos = Collections.binarySearch(eventos, e, TituloevComp);
        if (pos >= 0) {
            objevento = eventos.get(pos);
        } else {
            objevento = null;
        }

        return objevento;
    }
    
    /** Consulta los datos de un Cliente por su nombre
     * @param nombre
     * @return  */
    public static Cliente consultaClientePorNombre(String nombre) {
        //Comparador para ordenar los Clientes por su nombre
        Comparator NomcliComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Cliente c1 = (Cliente) o1;
                Cliente c2 = (Cliente) o2;
                return c1.getNombre().compareTo(c2.getNombre());
            }
        };
        //Ordenamos el array
        Collections.sort(clientes, NomcliComp);
        //creamos un Cliente con el nombre a buscar
        Cliente c = new Cliente();
        c.setNombre(nombre);
        int pos = Collections.binarySearch(clientes, c, NomcliComp);
        if (pos >= 0) {
            objcliente = clientes.get(pos);
        } else {
            objcliente = null;
        }
        return objcliente;
    }
    
    /** Consulta los datos de una Resena por su evento
     * @param evento
     * @return  */
    public static Reserva consultaReservaPorEvento(Evento evento) {
        //Comparador para ordenar las Reservas por su Evento
        Comparator ResEvComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Reserva r1 = (Reserva) o1;
                Reserva r2 = (Reserva) o2;
                return r1.getEvento().compareTo(r2.getEvento());
            }
        };
        //Ordenamos el array
        Collections.sort(reservas, ResEvComp);
        //creamos un Evento con el nombre a buscar
        Reserva c = new Reserva();
        c.setEvento(evento);
        int pos = Collections.binarySearch(reservas, c, ResEvComp);
        if (pos >= 0) {
            objreserva = reservas.get(pos);
        } else {
            objreserva = null;
        }
        return objreserva;
    }
    
    /** Consulta los datos de una Reserva por su cliente
     * @param cliente
     * @return  */
    public static Reserva consultaReservaPorCliente(Cliente cliente) {
        //Comparador para ordenar las Reservas por su nombre
        Comparator ResEvComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Reserva r1 = (Reserva) o1;
                Reserva r2 = (Reserva) o2;
                return r1.getCliente().compareTo(r2.getCliente());
            }
        };
        //Ordenamos el array
        Collections.sort(reservas, ResEvComp);
        //creamos un Reserva con el nombre a buscar
        Reserva c = new Reserva();
        c.setCliente(cliente);
        int pos = Collections.binarySearch(reservas, c, ResEvComp);
        if (pos >= 0) {
            objreserva = reservas.get(pos);
        } else {
            objreserva = null;
        }
        return objreserva;
    }
    
    /** Carga los datos de Clientes del fichero */
    public static void cargarDatosClientes() {
        try {
            try (FileInputStream istreampro = new FileInputStream("copiacli.dat")) {
                ObjectInputStream oispro = new ObjectInputStream(istreampro);
                clientes = (ArrayList) oispro.readObject();
            }
        } catch (IOException ioe) {
            System.out.println("Error de IO: " + ioe.getMessage());
            clientes = new ArrayList<>();
        } catch (ClassNotFoundException cnfe) {
            System.out.println("Error de clase no encontrada: " + cnfe.getMessage());
            clientes = new ArrayList<>();
        } 
    }//fin cargarDatosClientes
    
    /** Carga los datos de Eventos del fichero */
    public static void cargarDatosEventos() {
        try {
            try (FileInputStream istreampro = new FileInputStream("copiaeve.dat")) {
                ObjectInputStream oispro = new ObjectInputStream(istreampro);
                eventos = (ArrayList) oispro.readObject();
            }
        } catch (IOException ioe) {
            System.out.println("Error de IO: " + ioe.getMessage());
        } catch (ClassNotFoundException cnfe) {
            System.out.println("Error de clase no encontrada: " + cnfe.getMessage());
        } 
    }//fin cargarDatosEventos
    
    /** Carga los datos de Reservas del fichero */
    public static void cargarDatosReservas() {
        try {
            try (FileInputStream istreampro = new FileInputStream("copiares.dat")) {
                ObjectInputStream oispro = new ObjectInputStream(istreampro);
                reservas = (ArrayList) oispro.readObject();
            }
        } catch (IOException ioe) {
            System.out.println("Error de IO: " + ioe.getMessage());
        } catch (ClassNotFoundException cnfe) {
            System.out.println("Error de clase no encontrada: " + cnfe.getMessage());
        } 
    }//fin cargarDatosReservas
    
    /** Carga los datos de Resenas del fichero */
    public static void cargarDatosResenas() {
        try {
            try (FileInputStream istreampro = new FileInputStream("copiaresenas.dat")) {
                ObjectInputStream oispro = new ObjectInputStream(istreampro);
                resenas = (ArrayList) oispro.readObject();
            }
        } catch (IOException ioe) {
            System.out.println("Error de IO: " + ioe.getMessage());
        } catch (ClassNotFoundException cnfe) {
            System.out.println("Error de clase no encontrada: " + cnfe.getMessage());
        } 
    }//fin cargarDatosResenas
    
    
    /** Guarda los datos de Clientes en el fichero */
    public static void guardarDatosClientes() {
        try {
            //Si hay datos los guardamos...
            if (!clientes.isEmpty()) {
                try (FileOutputStream ostreampro = new FileOutputStream("copiacli.dat")) {
                    ObjectOutputStream oospro = new ObjectOutputStream(ostreampro);
                    //guardamos el array de clientes
                    oospro.writeObject(clientes);
                }
            } else {
                System.out.println("Error: No hay datos...");
            }

        } catch (IOException ioe) {
            System.out.println("Error de IO: " + ioe.getMessage());
        } 
    }//fin guardarDatosClientes
    
    /** Guarda los datos de Eventos en el fichero */
    public static void guardarDatosEventos() {
        try {
            //Si hay datos los guardamos...
            if (!eventos.isEmpty()) {
                try (FileOutputStream ostreampro = new FileOutputStream("copiaeve.dat")) {
                    ObjectOutputStream oospro = new ObjectOutputStream(ostreampro);
                    //guardamos el array de clientes
                    oospro.writeObject(eventos);
                }
            } else {
                System.out.println("Error: No hay datos...");
            }

        } catch (IOException ioe) {
            System.out.println("Error de IO: " + ioe.getMessage());
        } 
    }//fin guardarDatosEventos
    
    /** Guarda los datos de Reservas en el fichero */
    public static void guardarDatosReservas() {
        try {
            //Si hay datos los guardamos...
            if (!reservas.isEmpty()) {
                try (FileOutputStream ostreampro = new FileOutputStream("copiares.dat")) {
                    ObjectOutputStream oospro = new ObjectOutputStream(ostreampro);
                    //guardamos el array de clientes
                    oospro.writeObject(reservas);
                }
            } else {
                System.out.println("Error: No hay datos...");
            }

        } catch (IOException ioe) {
            System.out.println("Error de IO: " + ioe.getMessage());
        } 
    }//fin guardarDatosReservas
    
    /** Guarda los datos de Resenas en el fichero */
    public static void guardarDatosResenas() {
        try {
            //Si hay datos los guardamos...
            if (!resenas.isEmpty()) {
                try (FileOutputStream ostreampro = new FileOutputStream("copiaresenas.dat")) {
                    ObjectOutputStream oospro = new ObjectOutputStream(ostreampro);
                    //guardamos el array de clientes
                    oospro.writeObject(resenas);
                }
            } else {
                System.out.println("Error: No hay datos...");
            }

        } catch (IOException ioe) {
            System.out.println("Error de IO: " + ioe.getMessage());
        } 
    }//fin guardarDatosResenas
    
    
    /**
     * Genera una factura en un archivo de texto para un evento dado, con la cantidad
     * de entradas compradas y la información del cliente.
     * El archivo se guarda en la carpeta "./Facturas" y su nombre incluye la fecha,
     * hora, nombre del cliente y título del evento para evitar sobrescrituras.
     *
     * @param evento           El evento para el que se genera la factura.
     * @param cantidadEntradas La cantidad de entradas compradas.
     * @param cliente          El cliente que realiza la compra.
     * @throws IOException Si ocurre un error al crear o escribir el archivo.
     */
    public static void generaFactura(Evento evento, int cantidadEntradas, Cliente cliente) throws IOException {
        LocalDateTime ahora = LocalDateTime.now();
        DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd_MM_yyyy");
        DateTimeFormatter formatoHora = DateTimeFormatter.ofPattern("HH_mm_ss");

        String fecha = ahora.format(formatoFecha);
        String hora = ahora.format(formatoHora);

        String nombreCliente = limpiarNombreArchivo(cliente.getNombre());
        String tituloEvento = limpiarNombreArchivo(evento.getTitulo());

        String rutaFicheroFactura = String.format(
            "./Facturas/FacturaEvento_%s_%s_%s_%s.txt",
            fecha, hora, nombreCliente, tituloEvento
        );

        // Crear carpeta si no existe
        File dirFacturas = new File("./Facturas");
        if (!dirFacturas.exists()) {
            dirFacturas.mkdir();
        }

        try {
            double precioEntrada = Double.parseDouble(evento.getPrecioEntrada());
            double total = precioEntrada * cantidadEntradas;

            if (cliente.esVip()) {
                total *= 0.9; // 10% descuento para clientes VIP
            }

            try (PrintWriter salida = new PrintWriter(new BufferedWriter(new FileWriter(rutaFicheroFactura)))) {
                salida.println("----------------------------- FACTURA EVENTO -----------------------------");
                salida.println("Fecha: " + ahora.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")));
                salida.println("Cliente: " + cliente.getNombre());
                salida.println("Tipo Cliente: " + (cliente.esVip() ? "VIP (10% descuento)" : "Estándar"));
                salida.println();
                salida.println("Título: " + evento.getTitulo());
                salida.println("Tipo: " + evento.getTipo());
                salida.println("Dirección: " + evento.getDireccion());
                salida.println("Precio entrada: " + String.format("%.2f", precioEntrada) + " €");
                salida.println("Cantidad de entradas: " + cantidadEntradas);
                salida.println("--------------------------------------------------------------------------");
                salida.println("IMPORTE TOTAL: " + String.format("%.2f", total) + " €");
                salida.println("--------------------------------------------------------------------------");
            }

        } catch (NumberFormatException ex) {
            System.out.println("Precio de entrada inválido: " + evento.getPrecioEntrada());
        } catch (IOException ioe) {
            System.out.println("Error de IO al generar factura: " + ioe.getMessage());
        }
    }

    /**
     * Limpia una cadena de texto para que sea válida como nombre de archivo,
     * reemplazando caracteres que no sean letras, números, guiones o guiones bajos por '_'.
     *
     * @param nombre La cadena original que se quiere limpiar.
     * @return Una cadena segura para usar en nombres de archivo.
     */
    private static String limpiarNombreArchivo(String nombre) {
        return nombre.replaceAll("[^a-zA-Z0-9\\-_]", "_");
    }
}
