
package ClasesJavaEvents;

/**
 *Clase Administrador
 * 
 * @author RAMON
 */
import java.io.Serializable;

/**
 * Representa un administrador del sistema con un correo y una clave.
 * Esta clase implementa Serializable para permitir su persistencia.
 */
public class Administrador implements Serializable {

    private String correo; // Correo único del administrador
    private String clave;  // Clave asociada al administrador

    /**
     * Crea un nuevo administrador con valores predeterminados.
     * Por defecto, se asignan los valores:
     * correo = "admin@javaevents.com"
     * clave = "admin"
     *
     * @param correo 
     * @param clave  
     */
    public Administrador(String correo, String clave) {
        this.correo = "admin@javaevents.com";
        this.clave = "admin";
    }

    /**
     * Obtiene el correo del administrador.
     *
     * @return el correo del administrador.
     */
    public String getCorreo() {
        return correo;
    }

    /**
     * Establece el correo del administrador.
     *
     * @param correo el nuevo correo a asignar.
     */
    public void setCorreo(String correo) {
        this.correo = correo;
    }

    /**
     * Obtiene la clave del administrador.
     *
     * @return la clave del administrador.
     */
    public String getClave() {
        return clave;
    }

    /**
     * Establece la clave del administrador.
     *
     * @param clave la nueva clave a asignar.
     */
    public void setClave(String clave) {
        this.clave = clave;
    }
}
