
package ClasesJavaEvents;

/**
 *Clase Cliente
 * 
 * @author RAMON
 */

import java.util.ArrayList;
import java.io.Serializable;

/**
 * Representa un cliente del sistema, que puede realizar reservas y
 * dejar reseñas. Implementa Serializable para permitir la persistencia
 * y Comparable para poder ordenar clientes por nombre.
 */
public class Cliente implements Serializable, Comparable<Cliente> {
    
    private String nombre;              // Nombre del cliente
    private String correo;              // Correo del cliente
    private String clave;               // Clave del cliente
    private String telefono;            // Teléfono asociado al cliente
    private Boolean esVip;              // Indica si el cliente es parte del grupo VIP o no
    private ArrayList<Reserva> reservas = new ArrayList<>(); // Lista de reservas asociadas
    private Direccion direccion;        // Dirección del cliente
    private TarjetaCredito tarjeta;     // Tarjeta de crédito del cliente
    private ArrayList<Resena> resenas = new ArrayList<>();   // Lista de reseñas del cliente
    
    /**
     * Constructor vacío por defecto.
     */
    public Cliente() {}

    /**
     * Crea un nuevo cliente con los datos especificados.
     * Por defecto, el cliente no es VIP.
     *
     * @param nombre    Nombre del cliente.
     * @param correo    Correo electrónico del cliente.
     * @param clave     Clave de acceso del cliente.
     * @param telefono  Teléfono del cliente.
     * @param direccion Dirección del cliente.
     * @param tarjeta   Tarjeta de crédito asociada al cliente.
     */
    public Cliente(String nombre, String correo, String clave, String telefono, Direccion direccion, TarjetaCredito tarjeta) {
        this.nombre = nombre;
        this.correo = correo;
        this.clave = clave;
        this.telefono = telefono;
        this.esVip = false;
        this.direccion = direccion;
        this.tarjeta = tarjeta;
    }

    /**
     * Obtiene el nombre del cliente.
     *
     * @return nombre del cliente.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre del cliente.
     *
     * @param nombre nuevo nombre.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene el correo electrónico del cliente.
     *
     * @return correo del cliente.
     */
    public String getCorreo() {
        return correo;
    }

    /**
     * Establece el correo electrónico del cliente.
     *
     * @param correo nuevo correo.
     */
    public void setCorreo(String correo) {
        this.correo = correo;
    }

    /**
     * Obtiene la clave del cliente.
     *
     * @return clave del cliente.
     */
    public String getClave() {
        return clave;
    }

    /**
     * Establece la clave del cliente.
     *
     * @param clave nueva clave.
     */
    public void setClave(String clave) {
        this.clave = clave;
    }

    /**
     * Obtiene el teléfono del cliente.
     *
     * @return teléfono del cliente.
     */
    public String getTelefono() {
        return telefono;
    }

    /**
     * Establece el teléfono del cliente.
     *
     * @param telefono nuevo teléfono.
     */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    /**
     * Indica si el cliente pertenece al grupo VIP.
     *
     * @return true si es VIP, false en caso contrario.
     */
    public Boolean esVip() {
        return esVip;
    }

    /**
     * Establece si el cliente es VIP o no.
     *
     * @param esVip valor booleano para VIP.
     */
    public void setEsVip(Boolean esVip) {
        this.esVip = esVip;
    }

    /**
     * Obtiene la dirección del cliente.
     *
     * @return dirección del cliente.
     */
    public Direccion getDireccion() {
        return direccion;
    }

    /**
     * Establece la dirección del cliente.
     *
     * @param direccion nueva dirección.
     */
    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
    }

    /**
     * Obtiene la tarjeta de crédito del cliente.
     *
     * @return tarjeta de crédito.
     */
    public TarjetaCredito getTarjeta() {
        return tarjeta;
    }

    /**
     * Establece la tarjeta de crédito del cliente.
     *
     * @param tarjeta nueva tarjeta de crédito.
     */
    public void setTarjeta(TarjetaCredito tarjeta) {
        this.tarjeta = tarjeta;
    }

    /**
     * Obtiene la lista de reservas del cliente.
     *
     * @return lista de reservas.
     */
    public ArrayList<Reserva> getReservas() {
        return reservas;
    }

    /**
     * Añade una nueva reserva a la lista de reservas del cliente.
     *
     * @param reserva reserva a añadir.
     */
    public void anadirReserva(Reserva reserva) {
        reservas.add(reserva);
    }

    /**
     * Añade una reseña a la lista de reseñas del cliente.
     *
     * @param resena reseña a añadir.
     */
    public void anadirResena(Resena resena) {
        resenas.add(resena);
    }

    /**
     * Verifica si el cliente ya ha calificado un evento específico.
     *
     * @param evento evento a verificar.
     * @return true si ya ha calificado el evento, false si no.
     */
    public boolean haCalificadoEvento(Evento evento) {
        for (Resena r : resenas) {
            if (r.getEvento().equals(evento)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Representación en cadena del cliente.
     *
     * @return cadena con los datos del cliente.
     */
    @Override
    public String toString() {
        return "Cliente{" +
                "nombre='" + nombre + '\'' +
                ", correo='" + correo + '\'' +
                ", clave='" + clave + '\'' +
                ", telefono='" + telefono + '\'' +
                ", direccion=" + direccion +
                ", tarjeta=" + tarjeta +
                ", reservas=" + reservas +
                ", esVip=" + esVip +
                '}';
    }

    /**
     * Compara este cliente con otro por nombre.
     *
     * @param c cliente a comparar.
     * @return resultado de la comparación lexicográfica del nombre.
     */
    @Override
    public int compareTo(Cliente c) {
        return this.nombre.compareTo(c.getNombre());
    }
}
    

