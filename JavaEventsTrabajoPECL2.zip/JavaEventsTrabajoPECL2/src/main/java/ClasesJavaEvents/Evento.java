
package ClasesJavaEvents;

/**
 *Clase Evento
 * 
 * @author RAMON
 */
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Objects;
import javax.swing.Icon;

/**
 * Representa un evento con sus detalles como título, tipo, ubicación,
 * fecha, hora, precio, imagen, calificación y reseñas asociadas.
 */
public class Evento implements Serializable, Comparable<Evento> {
    private String titulo; // nombre del evento
    private String tipo; // tipo de evento (concierto, obra de teatro, etc.)
    private Direccion direccion; // direccion del evento
    private String fecha; // fecha del evento
    private String hora; // hora del evento
    private String precioEntrada; // precioEntrada del evento
    private String ruta; // direccion de la imagen del evento
    private double calificacion; // calificacion del evento (1-5)
    private ArrayList<Resena> resenas;//lista de reseñas del evento

    /**
     * Constructor vacío para crear un evento sin inicializar sus atributos.
     */
    public Evento(){}

    /**
     * Constructor para crear un evento con todos sus atributos.
     *
     * @param titulo        Título o nombre del evento.
     * @param tipo          Tipo de evento (concierto, obra de teatro, etc.).
     * @param direccion     Dirección donde se realizará el evento.
     * @param fecha         Fecha del evento.
     * @param hora          Hora del evento.
     * @param precioEntrada Precio de la entrada para el evento.
     * @param ruta          Ruta o dirección de la imagen del evento.
     * @param calificacion  Calificación del evento (de 1 a 5).
     */
    public Evento(String titulo, String tipo, Direccion direccion, String fecha, String hora, String precioEntrada, String ruta, double calificacion) {
        this.titulo = titulo;
        this.tipo = tipo;
        this.direccion = direccion;
        this.fecha = fecha;
        this.hora = hora;
        this.precioEntrada = precioEntrada;
        this.ruta = ruta;
        this.resenas = new ArrayList<>();
        this.calificacion = 0;
    }

    /**
     * Obtiene el título del evento.
     *
     * @return Título del evento.
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * Establece el título del evento.
     *
     * @param titulo Nuevo título del evento.
     */
    public void setTitulo(String titulo){
        this.titulo = titulo;
    }
    
    /**
     * Obtiene el tipo de evento.
     *
     * @return Tipo del evento.
     */
    public String getTipo(){
       return tipo;
    }
    
    /**
     * Establece el tipo de evento.
     *
     * @param tipo Nuevo tipo de evento.
     */
    public void setTipo(String tipo){
        this.tipo = tipo;
    }
    
    /**
     * Obtiene la dirección donde se realiza el evento.
     *
     * @return Dirección del evento.
     */
    public Direccion getDireccion(){
        return direccion;
    }
    
    /**
     * Establece la dirección del evento.
     *
     * @param direccion Nueva dirección del evento.
     */
    public void setDireccion(Direccion direccion){
        this.direccion = direccion;     
    }
    
    /**
     * Obtiene la fecha del evento.
     *
     * @return Fecha del evento.
     */
    public String getFecha(){
        return fecha;
    }
    
    /**
     * Establece la fecha del evento.
     *
     * @param fecha Nueva fecha del evento.
     */
    public void setFecha(String fecha){
        this.fecha = fecha;
    }
    
    /**
     * Obtiene la hora del evento.
     *
     * @return Hora del evento.
     */
    public String getHora(){
        return hora;
    }
    
    /**
     * Establece la hora del evento.
     *
     * @param hora Nueva hora del evento.
     */
    public void setHora(String hora){
        this.hora = hora;
    }
    
    /**
     * Obtiene el precio de la entrada del evento.
     *
     * @return Precio de la entrada.
     */
    public String getPrecioEntrada(){
        return precioEntrada;
    }
    
    /**
     * Establece el precio de la entrada del evento.
     *
     * @param precioEntrada Nuevo precio de la entrada.
     */
    public void setPrecioEntrada(String precioEntrada){
        this.precioEntrada = precioEntrada;
    }
    
    /**
     * Obtiene la ruta de la imagen asociada al evento.
     *
     * @return Ruta de la imagen.
     */
    public String getRuta(){
        return ruta;
    }
    
    /**
     * Establece la ruta de la imagen asociada al evento.
     *
     * @param ruta Nueva ruta de la imagen.
     */
    public void setRuta(String ruta){
        this.ruta = ruta;
    }
    
    /**
     * Obtiene la calificación promedio del evento.
     *
     * @return Calificación del evento.
     */
    public double getCalificacion(){
        return calificacion;
    }
    
    /**
     * Calcula la calificación promedio del evento basado en las reseñas recibidas.
     * La calificación se actualiza internamente.
     */
    public void calculaCalificacion(){
        int suma = 0;
        for(Resena resena : resenas){
            suma += resena.getCalificacion();
        }
        this.calificacion = suma/resenas.size();
    }
    
    /**
     * Añade una reseña a la lista de reseñas del evento.
     *
     * @param r Reseña a añadir.
     */
    public void anadirResena(Resena r){
        resenas.add(r);
    }
    
    /**
     * Representación en cadena del evento con sus atributos principales.
     *
     * @return Cadena con información del evento.
     */
    @Override
    public String toString() {
        return "Evento{" +
                "titulo='" + titulo + '\'' +
                ", tipo='" + tipo + '\'' +
                ", direccion=" + direccion +
                ", fecha=" + fecha +
                ", hora=" + hora +
                ", precio=" + precioEntrada +
                ", ruta='" + ruta + '\'' +
                ", calificacion=" + calificacion +
                '}';
    }
    
    /**
     * Compara este evento con otro evento basado en el título.
     *
     * @param e Evento con el que se compara.
     * @return Resultado de la comparación de títulos.
     */
    @Override
    public int compareTo(Evento e){
        return this.titulo.compareTo(e.getTitulo());
    }
    
    /**
     * Calcula el código hash del evento basado en sus atributos.
     *
     * @return Código hash del evento.
     */
    @Override
    public int hashCode(){
        int hash = 7;
        hash = 89 * hash + Objects.hashCode(this.titulo);
        hash = 89 * hash + Objects.hashCode(this.tipo);
        hash = 89 * hash + Objects.hashCode(this.direccion);
        hash = 89 * hash + Objects.hashCode(this.fecha);
        hash = 89 * hash + Objects.hashCode(this.hora);
        hash = 89 * hash + Objects.hashCode(this.precioEntrada);
        hash = 89 * hash + Objects.hashCode(this.ruta);
        hash = 89 * hash + (int) (Double.doubleToLongBits(this.calificacion) ^ (Double.doubleToLongBits(this.calificacion) >>> 32));
        hash = 89 * hash + Objects.hashCode(this.resenas);
        return hash;
    }

    /**
     * Compara si otro objeto es igual a este evento basado en sus atributos.
     *
     * @param obj Objeto a comparar.
     * @return true si los objetos son iguales, false en caso contrario.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Evento other = (Evento) obj;
        if (!Objects.equals(this.precioEntrada, other.precioEntrada)){
            return false;
        }
        if (Double.doubleToLongBits(this.calificacion) != Double.doubleToLongBits(other.calificacion)) {
            return false;
        }
        if (!Objects.equals(this.titulo, other.titulo)) {
            return false;
        }
        if (!Objects.equals(this.tipo, other.tipo)) {
            return false;
        }
        if (!Objects.equals(this.ruta, other.ruta)) {
            return false;
        }
        if (!Objects.equals(this.direccion, other.direccion)) {
            return false;
        }
        if (!Objects.equals(this.fecha, other.fecha)) {
            return false;
        }
        if (!Objects.equals(this.hora, other.hora)) {
            return false;
        }
        return Objects.equals(this.resenas, other.resenas);
    }
}
