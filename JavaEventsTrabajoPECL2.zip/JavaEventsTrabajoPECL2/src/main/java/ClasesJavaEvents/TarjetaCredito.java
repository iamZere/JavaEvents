
package ClasesJavaEvents;

/**
 *Clase Tarjeta de Credito
 * 
 * @author RAMON
 */
import java.io.Serializable;


/**
 * Representa una tarjeta de crédito con información básica del titular,
 * número de tarjeta y fecha de caducidad.
 */
public class TarjetaCredito implements Serializable {
    
    private String nombreTitular;
    private String numeroTarjeta;
    private String fechaCaducidad;

    /**
     * Constructor que inicializa una tarjeta de crédito con los datos del titular,
     * número de tarjeta y fecha de caducidad.
     *
     * @param nombreTitular   Nombre del titular de la tarjeta.
     * @param numeroTarjeta   Número de la tarjeta de crédito.
     * @param fechaCaducidad  Fecha de caducidad de la tarjeta en formato String.
     */
    public TarjetaCredito(String nombreTitular, String numeroTarjeta, String fechaCaducidad) {    
        this.nombreTitular = nombreTitular;
        this.numeroTarjeta = numeroTarjeta;
        this.fechaCaducidad = fechaCaducidad;
    }

    /**
     * Obtiene el nombre del titular de la tarjeta.
     *
     * @return Nombre del titular.
     */
    public String getNombreTitular() {
        return nombreTitular;
    }

    /**
     * Establece el nombre del titular de la tarjeta.
     *
     * @param nombreTitular Nombre a asignar.
     */
    public void setNombreTitular(String nombreTitular) {
        this.nombreTitular = nombreTitular;
    }

    /**
     * Obtiene el número de la tarjeta de crédito.
     *
     * @return Número de tarjeta.
     */
    public String getNumeroTarjeta() {
        return numeroTarjeta;
    }

    /**
     * Establece el número de la tarjeta de crédito.
     *
     * @param numeroTarjeta Número a asignar.
     */
    public void setNumeroTarjeta(String numeroTarjeta) {
        this.numeroTarjeta = numeroTarjeta;
    }

    /**
     * Obtiene la fecha de caducidad de la tarjeta.
     *
     * @return Fecha de caducidad en formato String.
     */
    public String getFechaCaducidad() {
        return fechaCaducidad;
    }

    /**
     * Establece la fecha de caducidad de la tarjeta.
     *
     * @param fechaCaducidad Fecha a asignar.
     */
    public void setFechaCaducidad(String fechaCaducidad) {
        this.fechaCaducidad = fechaCaducidad;
    }

    /**
     * Representación en cadena de la tarjeta de crédito.
     *
     * @return Cadena con la información del titular, número y fecha de caducidad.
     */
    @Override
    public String toString() {
        return "TarjetaCredito{" +
                "nombreTitular='" + nombreTitular + '\'' +
                ", numeroTarjeta='" + numeroTarjeta + '\'' +
                ", fechaCaducidad='" + fechaCaducidad + '\'' +
                '}';
    }
}
