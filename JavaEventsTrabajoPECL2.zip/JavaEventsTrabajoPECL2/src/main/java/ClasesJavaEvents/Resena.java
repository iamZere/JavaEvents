
package ClasesJavaEvents;

/**
 *Clase Resena
 * 
 * @author RAMON
 */
import java.io.Serializable;

import java.io.Serializable;

/**
 * Representa una reseña realizada por un cliente a un evento.
 * Contiene la calificación (1-5) y un comentario opcional.
 */
public class Resena implements Serializable {

    private Evento evento;          // Evento que está siendo reseñado
    private Cliente cliente;        // Cliente que escribe la reseña
    private double calificacion;    // Calificación del 1 al 5
    private String comentario;      // Comentario opcional

    /**
     * Constructor que crea una reseña con los datos indicados.
     * Valida que el evento y cliente no sean nulos, y que la calificación sea válida.
     *
     * @param evento      Evento que está siendo reseñado, no puede ser null.
     * @param cliente     Cliente que escribe la reseña, no puede ser null.
     * @param calificacion Calificación entre 1 y 5.
     * @param comentario  Comentario opcional, puede ser null.
     * @throws IllegalArgumentException si evento o cliente son null o si la calificación no está en rango.
     */
    public Resena(Evento evento, Cliente cliente, double calificacion, String comentario) {
        if (evento == null) {
            throw new IllegalArgumentException("El evento no puede ser nulo.");
        }
        if (cliente == null) {
            throw new IllegalArgumentException("El cliente no puede ser nulo.");
        }
        if (calificacion < 1 || calificacion > 5) {
            throw new IllegalArgumentException("La calificación debe estar entre 1 y 5.");
        }
        
        this.evento = evento;
        this.cliente = cliente;
        this.calificacion = calificacion;
        this.comentario = comentario != null ? comentario : ""; // Si es null, asigna cadena vacía
    }

    /**
     * Constructor vacío por defecto.
     */
    public Resena() {}

    /**
     * Obtiene el evento reseñado.
     *
     * @return evento.
     */
    public Evento getEvento() {
        return evento;
    }

    /**
     * Establece el evento reseñado.
     * 
     * @param evento evento no puede ser null.
     * @throws IllegalArgumentException si evento es null.
     */
    public void setEvento(Evento evento) {
        if (evento == null) {
            throw new IllegalArgumentException("El evento no puede ser nulo.");
        }
        this.evento = evento;
    }

    /**
     * Obtiene el cliente que realizó la reseña.
     *
     * @return cliente.
     */
    public Cliente getCliente() {
        return cliente;
    }

    /**
     * Establece el cliente que realiza la reseña.
     * 
     * @param cliente cliente no puede ser null.
     * @throws IllegalArgumentException si cliente es null.
     */
    public void setCliente(Cliente cliente) {
        if (cliente == null) {
            throw new IllegalArgumentException("El cliente no puede ser nulo.");
        }
        this.cliente = cliente;
    }

    /**
     * Obtiene la calificación de la reseña.
     *
     * @return calificación entre 1 y 5.
     */
    public double getCalificacion() {
        return calificacion;
    }

    /**
     * Establece la calificación de la reseña.
     *
     * @param calificacion calificación entre 1 y 5.
     * @throws IllegalArgumentException si la calificación no está en rango.
     */
    public void setCalificacion(double calificacion) {
        if (calificacion < 1 || calificacion > 5) {
            throw new IllegalArgumentException("La calificación debe estar entre 1 y 5.");
        }
        this.calificacion = calificacion;
    }

    /**
     * Obtiene el comentario de la reseña.
     *
     * @return comentario (puede ser cadena vacía).
     */
    public String getComentario() {
        return comentario;
    }

    /**
     * Establece el comentario de la reseña.
     * 
     * @param comentario comentario opcional; si es null, se asigna cadena vacía.
     */
    public void setComentario(String comentario) {
        this.comentario = comentario != null ? comentario : "";
    }

    /**
     * Representación en cadena de la reseña.
     * Muestra título del evento, nombre del cliente, calificación y comentario.
     *
     * @return cadena descriptiva de la reseña.
     */
    @Override
    public String toString() {
        return "Resena{" +
                "evento=" + evento.getTitulo() + 
                ", cliente=" + cliente.getNombre() + 
                ", calificacion=" + calificacion +
                ", comentario='" + comentario + '\'' +
                '}';
    }
}
