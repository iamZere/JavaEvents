
package ClasesJavaEvents;

/**
 *
 * 
 * @author RAMON
 */
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

/**
 *
 * @author zerep
 */

/**
 * Representa una reserva realizada por un cliente para un evento.
 * Contiene información sobre la cantidad de entradas, fecha y importe.
 */
public class Reserva implements Serializable, Comparable<Reserva> {

    private Cliente cliente;
    private Evento evento;
    private LocalDate fecha;
    private int cantidadEntradas;
    private double importe;

    /**
     * Constructor que inicializa una reserva con los datos proporcionados.
     * La fecha de la reserva se establece a la fecha actual.
     *
     * @param cliente         Cliente que realiza la reserva.
     * @param evento          Evento para el que se hace la reserva.
     * @param cantidadEntradas Número de entradas reservadas.
     * @param fechaReserva    Fecha de la reserva (no se usa en el constructor, se fija LocalDate.now()).
     * @param importe         Importe total de la reserva.
     */
    public Reserva(Cliente cliente, Evento evento, int cantidadEntradas, LocalDate fechaReserva, double importe){
        this.cliente = cliente;
        this.evento = evento;
        this.cantidadEntradas = cantidadEntradas;
        this.fecha = LocalDate.now(); // Se ignora fechaReserva y se fija a la fecha actual
        this.importe = importe;      
    }

    /**
     * Constructor vacío por defecto.
     */
    public Reserva(){}

    /**
     * Obtiene el cliente que realizó la reserva.
     *
     * @return Cliente de la reserva.
     */
    public Cliente getCliente(){
        return cliente;
    }

    /**
     * Establece el cliente que realiza la reserva.
     *
     * @param cliente Cliente a asignar.
     */
    public void setCliente(Cliente cliente){
        this.cliente = cliente;
    }

    /**
     * Obtiene el evento reservado.
     *
     * @return Evento de la reserva.
     */
    public Evento getEvento(){
        return evento;
    }

    /**
     * Establece el evento de la reserva.
     *
     * @param evento Evento a asignar.
     */
    public void setEvento(Evento evento){
        this.evento = evento;
    }

    /**
     * Obtiene la fecha de la reserva.
     *
     * @return Fecha de la reserva.
     */
    public LocalDate getFecha(){
        return fecha;
    }

    /**
     * Establece la fecha de la reserva.
     *
     * @param fecha Fecha a asignar.
     */
    public void setFecha(LocalDate fecha){
        this.fecha = fecha;
    }

    /**
     * Obtiene la cantidad de entradas reservadas.
     *
     * @return Cantidad de entradas.
     */
    public int getCantidadEntradas() {
        return cantidadEntradas;
    }

    /**
     * Establece la cantidad de entradas reservadas.
     *
     * @param cantidadEntradas Cantidad a asignar.
     */
    public void setCantidadEntradas(int cantidadEntradas) {
        this.cantidadEntradas = cantidadEntradas;
    }

    /**
     * Obtiene el importe total de la reserva.
     *
     * @return Importe de la reserva.
     */
    public double getImporte(){
        return importe;
    }

    /**
     * Establece el importe total de la reserva.
     *
     * @param importe Importe a asignar.
     */
    public void setImporte(double importe){
        this.importe = importe;
    }

    /**
     * Representación en cadena de la reserva.
     *
     * @return Cadena descriptiva con cliente, evento, fecha e importe.
     */
    @Override
    public String toString(){
        return "Reserva{" + 
                "Cliente=" + cliente + 
                ", Evento=" + evento + 
                ", Fecha=" + fecha + 
                ", Importe=" + importe + 
                " }"; 
    }

    /**
     * Compara esta reserva con otra por el cliente asociado.
     *
     * @param r Otra reserva a comparar.
     * @return Resultado de la comparación por nombre del cliente.
     */
    @Override
    public int compareTo(Reserva r){
        return this.cliente.compareTo(r.getCliente());
    }

    /**
     * Calcula el código hash basado en cliente, evento, fecha e importe.
     *
     * @return Código hash de la reserva.
     */
    @Override
    public int hashCode(){
        int hash = 3;
        hash = 89 * hash + Objects.hashCode(this.cliente);
        hash = 89 * hash + Objects.hashCode(this.evento);
        hash = 89 * hash + Objects.hashCode(this.fecha);
        hash = 89 * hash + (int)(Double.doubleToLongBits(this.importe) ^ (Double.doubleToLongBits(this.importe) >>> 32));
        return hash;      
    }

    /**
     * Compara esta reserva con otro objeto para igualdad.
     * Dos reservas son iguales si tienen igual cliente, evento, fecha e importe.
     *
     * @param obj Objeto a comparar.
     * @return true si son iguales, false en caso contrario.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Reserva other = (Reserva) obj;
        if (Double.doubleToLongBits(this.importe) != Double.doubleToLongBits(other.importe)) {
            return false;
        }
        if (!Objects.equals(this.cliente, other.cliente)) {
            return false;
        }
        if (!Objects.equals(this.evento, other.evento)) {
            return false;
        }
        return Objects.equals(this.fecha, other.fecha);
    }
}