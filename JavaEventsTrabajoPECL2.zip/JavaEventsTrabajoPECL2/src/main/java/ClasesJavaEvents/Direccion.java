
package ClasesJavaEvents;

/**
 * Clase Dirección
 * 
 * @author RAMON
 */

import java.io.Serializable;

/**
 * Representa una dirección postal con calle, número, ciudad y código postal.
 * Implementa Serializable para permitir su persistencia y Comparable para ordenar por ciudad.
 */
public class Direccion implements Serializable, Comparable<Direccion> {

    private String calle;         // Nombre de la calle
    private String numero;        // Número del domicilio
    private String ciudad;        // Nombre de la ciudad
    private String codigoPostal;  // Código postal de la ciudad

    /**
     * Crea una nueva dirección con los datos especificados.
     *
     * @param calle       Nombre de la calle.
     * @param numero      Número del domicilio.
     * @param ciudad      Nombre de la ciudad.
     * @param codigoPostal Código postal de la ciudad.
     */
    public Direccion(String calle, String numero, String ciudad, String codigoPostal) {
        this.calle = calle;
        this.numero = numero;
        this.ciudad = ciudad;
        this.codigoPostal = codigoPostal;
    }

    /**
     * Obtiene el nombre de la calle.
     *
     * @return nombre de la calle.
     */
    public String getCalle() {
        return calle;
    }

    /**
     * Establece el nombre de la calle.
     *
     * @param calle nuevo nombre de la calle.
     */
    public void setCalle(String calle) {
        this.calle = calle;
    }

    /**
     * Obtiene el número del domicilio.
     *
     * @return número del domicilio.
     */
    public String getNumero() {
        return numero;
    }

    /**
     * Establece el número del domicilio.
     *
     * @param numero nuevo número del domicilio.
     */
    public void setNumero(String numero) {
        this.numero = numero;
    }

    /**
     * Obtiene el nombre de la ciudad.
     *
     * @return nombre de la ciudad.
     */
    public String getCiudad() {
        return ciudad;
    }

    /**
     * Establece el nombre de la ciudad.
     *
     * @param ciudad nuevo nombre de la ciudad.
     */
    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    /**
     * Obtiene el código postal de la ciudad.
     *
     * @return código postal.
     */
    public String getCodigoPostal() {
        return codigoPostal;
    }

    /**
     * Establece el código postal de la ciudad.
     *
     * @param codigoPostal nuevo código postal.
     */
    public void setCodigoPostal(String codigoPostal) {
        this.codigoPostal = codigoPostal;
    }

    /**
     * Representación en cadena de la dirección.
     *
     * @return cadena con todos los datos de la dirección.
     */
    @Override
    public String toString() {
        return "Direccion{" +
                "calle='" + calle + '\'' +
                ", numero='" + numero + '\'' +
                ", ciudad='" + ciudad + '\'' +
                ", codigoPostal='" + codigoPostal + '\'' +
                '}';
    }

    /**
     * Compara esta dirección con otra por nombre de ciudad.
     *
     * @param d dirección a comparar.
     * @return resultado de la comparación lexicográfica de la ciudad.
     */
    @Override
    public int compareTo(Direccion d) {
        return this.ciudad.compareTo(d.getCiudad());
    }
}
