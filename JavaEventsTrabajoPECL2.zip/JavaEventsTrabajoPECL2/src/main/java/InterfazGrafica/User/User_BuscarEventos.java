package InterfazGrafica.User;

import ClasesJavaEvents.Cliente;
import ClasesJavaEvents.Evento;
import ClasesJavaEvents.JavaEventsUtils;
import java.awt.Frame;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author RAMON
 */
public class User_BuscarEventos extends javax.swing.JFrame {
    
    /**
     * Referencia al cliente encontrado durante el proceso de autenticación o búsqueda.
    */
    private Cliente clienteEncontrado;

    /**
    * Modelo de tabla utilizado para gestionar los datos mostrados en la tabla de eventos.
    */
    private DefaultTableModel dtm = new DefaultTableModel();

    /**
    * Lista de eventos disponibles o gestionados en la aplicación.
    */
    private ArrayList<Evento> eventos;

    /**
     * Referencia al frame principal de la aplicación, utilizado para navegación o interacción entre ventanas.
     */
    private Frame principal;

    /**
    * Ordenador de filas para el modelo de tabla, permite filtrar y ordenar los datos de la tabla de eventos.
    */
    private TableRowSorter<DefaultTableModel> sorter;
    
    /**
    * Crea una nueva ventana para que el usuario pueda buscar eventos.
    * Inicializa los componentes gráficos, carga los eventos disponibles y configura la tabla de resultados.
    * También añade los listeners necesarios para la búsqueda tanto desde el botón como desde el campo de texto.
    *
    * @param cli El cliente que ha iniciado sesión y utilizará la funcionalidad de búsqueda de eventos.
    */
    public User_BuscarEventos(Cliente cli) {
        clienteEncontrado = cli;
        initComponents();
        JavaEventsUtils.cargarDatosEventos();
        eventos = JavaEventsUtils.getEventosPorTitulo();
        principal = this;
        String[] columnas = {"Titulo", "Tipo", "Fecha", "Precio", "Dirección"};
        dtm.setColumnIdentifiers(columnas);
        jTable1.setModel(dtm);
        jTable1.getTableHeader().setReorderingAllowed(false);
        sorter = new TableRowSorter<>(dtm);
        jTable1.setRowSorter(sorter);
        rellenaTabla();

        // Añadimos ActionListener al botón BUSCAR
        BotonHacerBusqueda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filtrarEventosPorTexto();
            }
        });

        // Añadimos ActionListener al campo de texto para buscar al pulsar Enter
        CajaRelleno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filtrarEventosPorTexto();
            }
        });
    }
    
    /**
    * Llena la tabla de eventos con los datos almacenados en la lista de eventos.
    * Primero limpia la tabla y luego añade una fila por cada evento, mostrando su título, tipo, fecha,
    * precio de entrada y dirección.
    */
    public void rellenaTabla() {
        limpiaTabla();
        for (Evento e : eventos) {
            dtm.addRow(new Object[]{
                e.getTitulo(),
                e.getTipo(),
                e.getFecha(),
                e.getPrecioEntrada(),
                e.getDireccion().getCalle()
            });
        }
    }
    
    /**
    * Elimina todas las filas de la tabla de eventos.
    * Recorre el modelo de la tabla y elimina cada fila para dejar la tabla vacía.
    */
    public void limpiaTabla() {
        int filas = dtm.getRowCount();
        for (int i = 0; i < filas; i++) {
            dtm.removeRow(0);
        }
    }
    
    /**
    * Filtra la lista de eventos según el criterio y el texto introducido por el usuario.
    * El criterio puede ser por ciudad o por tipo de evento. Si encuentra coincidencias,
    * las muestra en la tabla; si no, informa al usuario de que no se encontraron resultados.
    */
    public void filtrarEventosPorTexto() {
        
        String criterio = (String) ComboBoxCriterioBusqueda.getSelectedItem();
        String texto = CajaRelleno.getText().trim().toLowerCase();

        limpiaTabla();

        boolean encontrado = false;

        for (Evento e : eventos) {
            if ("Ciudad".equals(criterio)) {
                if (e.getDireccion().getCiudad().toLowerCase().contains(texto)) {
                    dtm.addRow(new Object[]{
                        e.getTitulo(),
                        e.getTipo(),
                        e.getFecha(),
                        e.getPrecioEntrada(),
                        e.getDireccion().getCalle()
                    });
                    encontrado = true;
                }
            } else if ("Tipo".equals(criterio)) {
                if (e.getTipo().toLowerCase().contains(texto)) {
                    dtm.addRow(new Object[]{
                        e.getTitulo(),
                        e.getTipo(),
                        e.getFecha(),
                        e.getPrecioEntrada(),
                        e.getDireccion().getCalle()
                    });
                    encontrado = true;
                }
            }
        }

        if (!encontrado) {
            JOptionPane.showMessageDialog(this, "No se encontraron eventos para ese filtro.", "Información", JOptionPane.INFORMATION_MESSAGE);
        }
    }
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Background = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        BordeInfFoto = new javax.swing.JLabel();
        LogoColor = new javax.swing.JLabel();
        BuscarEvento = new javax.swing.JLabel();
        DescripcionPestana = new javax.swing.JLabel();
        Tipo = new javax.swing.JLabel();
        ComboBoxCriterioBusqueda = new javax.swing.JComboBox<>();
        BotonVolver = new javax.swing.JButton();
        Separador = new javax.swing.JSeparator();
        CajaRelleno = new javax.swing.JTextField();
        BotonHacerBusqueda = new javax.swing.JButton();
        BotonReservar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Background.setBackground(new java.awt.Color(255, 255, 255));
        Background.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Titulo", "Tipo", "Fecha", "Precio", "Ciudad"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        Background.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, 740, 290));
        Background.add(BordeInfFoto, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 570, 800, 30));

        LogoColor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ImagenesPro/LogoColor_Resized.png"))); // NOI18N
        Background.add(LogoColor, new org.netbeans.lib.awtextra.AbsoluteConstraints(-30, 30, 360, 60));

        BuscarEvento.setFont(new java.awt.Font("Bahnschrift", 0, 48)); // NOI18N
        BuscarEvento.setText("BUSCAR EVENTOS");
        Background.add(BuscarEvento, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 20, 410, 80));

        DescripcionPestana.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        DescripcionPestana.setText("Permite visualizar todos los eventos disponibles en la app de JavaEvents.");
        Background.add(DescripcionPestana, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 110, 440, 30));

        Tipo.setFont(new java.awt.Font("Bahnschrift", 0, 14)); // NOI18N
        Tipo.setText("BUSCAR POR:");
        Background.add(Tipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, 100, 30));

        ComboBoxCriterioBusqueda.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        ComboBoxCriterioBusqueda.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ciudad", "Tipo" }));
        ComboBoxCriterioBusqueda.setBorder(null);
        ComboBoxCriterioBusqueda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxCriterioBusquedaActionPerformed(evt);
            }
        });
        Background.add(ComboBoxCriterioBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 150, 110, 30));

        BotonVolver.setFont(new java.awt.Font("Bahnschrift", 0, 14)); // NOI18N
        BotonVolver.setText("<- Volver al Menú");
        BotonVolver.setBorderPainted(false);
        BotonVolver.setContentAreaFilled(false);
        BotonVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonVolverActionPerformed(evt);
            }
        });
        Background.add(BotonVolver, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 540, 150, 30));

        Separador.setBackground(new java.awt.Color(0, 0, 0));
        Separador.setForeground(new java.awt.Color(0, 0, 0));
        Background.add(Separador, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 100, 720, 20));

        CajaRelleno.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        CajaRelleno.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        CajaRelleno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CajaRellenoActionPerformed(evt);
            }
        });
        Background.add(CajaRelleno, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 150, 160, 30));

        BotonHacerBusqueda.setFont(new java.awt.Font("Bahnschrift", 0, 14)); // NOI18N
        BotonHacerBusqueda.setText("BUSCAR");
        BotonHacerBusqueda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonHacerBusquedaActionPerformed(evt);
            }
        });
        Background.add(BotonHacerBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 150, -1, -1));

        BotonReservar.setFont(new java.awt.Font("Bahnschrift", 0, 14)); // NOI18N
        BotonReservar.setText("RESERVAR");
        BotonReservar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonReservarActionPerformed(evt);
            }
        });
        Background.add(BotonReservar, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 500, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(Background, javax.swing.GroupLayout.PREFERRED_SIZE, 800, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(Background, javax.swing.GroupLayout.PREFERRED_SIZE, 600, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
    /**
    * Acción ejecutada al cambiar la selección del criterio de búsqueda en el ComboBox.
    * Actualiza la tabla de eventos según el nuevo criterio seleccionado.
    *
    * @param evt El evento de acción generado por el ComboBox.
    */
    private void ComboBoxCriterioBusquedaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBoxCriterioBusquedaActionPerformed
        // TODO add your handling code here:
        String orden = (String) ComboBoxCriterioBusqueda.getSelectedItem();
        rellenaTabla();
    }//GEN-LAST:event_ComboBoxCriterioBusquedaActionPerformed
    
    /**
    * Acción ejecutada al pulsar el botón para volver al menú de usuario.
    * Abre la ventana del menú de usuario con el cliente actual y cierra la ventana actual.
    *
    * @param evt El evento de acción generado por el botón.
    */
    private void BotonVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonVolverActionPerformed
        // TODO add your handling code here:
        User_Menu frame1 = new User_Menu(clienteEncontrado);
        frame1.setVisible(true);
        dispose();
    }//GEN-LAST:event_BotonVolverActionPerformed
    
    /**
    * Acción ejecutada al interactuar con el campo de texto de búsqueda.
    *
    * @param evt El evento de acción generado por la interacción con el campo de texto.
    */
    private void CajaRellenoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CajaRellenoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CajaRellenoActionPerformed
    
    /**
    * Acción ejecutada al pulsar el botón para realizar la búsqueda de eventos.
    *
    * @param evt El evento de acción generado por el botón de búsqueda.
    */
    private void BotonHacerBusquedaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonHacerBusquedaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BotonHacerBusquedaActionPerformed
    
    /**
    * Acción ejecutada al pulsar el botón "Reservar".
    * Verifica que se haya seleccionado un evento en la tabla, busca el evento correspondiente
    * y abre la ventana de reserva para dicho evento. Muestra mensajes de error si no hay selección
    * o si el evento no se encuentra en la lista.
    *
    * @param evt El evento de acción generado por el botón de reserva.
    */
    private void BotonReservarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonReservarActionPerformed
        // TODO add your handling code here:
        int fila = jTable1.getSelectedRow();
        if (fila == -1) {
        JOptionPane.showMessageDialog(this, "No hay evento seleccionado.", "Mensaje", JOptionPane.ERROR_MESSAGE);
        } else {
        String tituloEvento = jTable1.getValueAt(fila, 0).toString(); // Reemplaza columnaTitulo por el índice correcto de la columna título

        Evento eventoEncontrado = null;
        for (Evento ev : eventos) {
            if (ev.getTitulo().equals(tituloEvento)) {
                eventoEncontrado = ev;
            break;
            }
        }
        if (eventoEncontrado != null) {
            User_ReservarEvento reservador = new User_ReservarEvento(clienteEncontrado, eventoEncontrado); 
            reservador.setVisible(true);
            this.dispose();
        } else {
        JOptionPane.showMessageDialog(this, "No se encontró el evento seleccionado.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_BotonReservarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(User_BuscarEventos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(User_BuscarEventos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(User_BuscarEventos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(User_BuscarEventos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Background;
    private javax.swing.JLabel BordeInfFoto;
    private javax.swing.JButton BotonHacerBusqueda;
    private javax.swing.JButton BotonReservar;
    private javax.swing.JButton BotonVolver;
    private javax.swing.JLabel BuscarEvento;
    private javax.swing.JTextField CajaRelleno;
    private javax.swing.JComboBox<String> ComboBoxCriterioBusqueda;
    private javax.swing.JLabel DescripcionPestana;
    private javax.swing.JLabel LogoColor;
    private javax.swing.JSeparator Separador;
    private javax.swing.JLabel Tipo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
